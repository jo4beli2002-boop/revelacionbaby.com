# Revelación baby · Cloudflare

Versión completa con HUD PC/Móvil, familias, PDF y correos.

## Workers Builds
- Root directory: `cloudflare`
- Build command: dejar vacío
- Deploy command: `npm run deploy`
- Preview builds: desactivadas durante la configuración inicial

El despliegue crea los enlaces DB (D1) y BUCKET (R2) y aplica las migraciones. R2 puede requerir habilitación previa en la cuenta.

## Configuración privada
Agregar `PRIVATE_SEED` como Secret del Worker antes de abrir el registro. No subir contraseñas, claves de correo, datos de invitados ni el contenido del Secret al repositorio.

## Plan gratuito
Comprobar en la cuenta real la generación de PDF, sesiones, persistencia, correos y límites de CPU. No asumir que el plan gratuito basta antes de las pruebas.
