# Enlace gratuito del evento

Worker ligero que sirve la invitación ya publicada. No necesita D1, R2 ni secretos. El HUD, datos y correos siguen en el servidor existente. No es un traslado completo ni un dominio propio.

Compilación: `tar -xzf Cloudflare-revelacionbaby.tar.gz && npm --prefix cloudflare install`
Despliegue: `npm --prefix cloudflare run deploy`

Usar el plan gratuito y comprobar los límites y el funcionamiento antes de compartir.
