import {api,userFor} from '../cloud/api.js';
const security={'X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'self'; form-action 'self'"};
export default {async fetch(request:Request,env:any,ctx:ExecutionContext){
 const url=new URL(request.url);let response;
 if(url.pathname.startsWith('/api/'))response=await api(request,env,ctx);
 else if(['/editor.js','/visual-editor.js','/animation-upload.js','/notification-panel.js'].includes(url.pathname)&&(await userFor(request,env))?.role!=='admin')response=new Response('Acceso reservado al administrador.',{status:403});
 else if(url.pathname.startsWith('/assets/upload-')){const file=await env.BUCKET.get(url.pathname.slice(1),{range:request.headers});if(!file)response=new Response('No encontrado',{status:404});else{const headers=new Headers();file.writeHttpMetadata(headers);headers.set('ETag',file.httpEtag);headers.set('Accept-Ranges','bytes');if(file.range){headers.set('Content-Range','bytes '+file.range.offset+'-'+(file.range.offset+file.range.length-1)+'/'+file.size);response=new Response(request.method==='HEAD'?null:file.body,{status:206,headers});}else response=new Response(request.method==='HEAD'?null:file.body,{headers});}}
 else{if(url.pathname==='/')url.pathname='/index.html';response=await env.ASSETS.fetch(new Request(url,request));}
 const headers=new Headers(response.headers);for(const [k,v]of Object.entries(security))headers.set(k,v);if(url.pathname.startsWith('/api/'))headers.set('Cache-Control','no-store');else if(!url.pathname.startsWith('/assets/'))headers.set('Cache-Control','no-cache');return new Response(response.body,{status:response.status,statusText:response.statusText,headers});
}};
