import {finishProjectSave,getPage} from './app.js';
export const canvasMode=window.parent!==window&&['mobile','desktop'].includes(new URLSearchParams(location.search).get('canvas'))?new URLSearchParams(location.search).get('canvas'):null;
export const deviceCanvas=!!canvasMode;
export function deviceButtons(panel){
 const row=document.createElement('div');row.className='device-switch';
 for(const [key,label]of [['desktop','PC'],['mobile','Móvil']]){
  const button=document.createElement('button');button.type='button';button.textContent=label;button.setAttribute('aria-pressed',String((canvasMode||'desktop')===key));
  button.addEventListener('click',async()=>{if(!await finishProjectSave())return;const url=new URL(location.href);url.searchParams.delete('canvas');url.searchParams.set('editor','1');url.searchParams.set('device',key);if(deviceCanvas)window.parent.location.href=url.href;else location.href=url.href;});row.append(button);
 }
 const exit=document.createElement('button');exit.type='button';exit.textContent='Cerrar sesión';exit.addEventListener('click',async()=>{if(!await finishProjectSave())return;const response=await fetch('/api/logout',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});if(response.ok)(deviceCanvas?window.parent:window).location.href=location.origin+location.pathname;});row.append(exit);
 const note=document.createElement('small');note.textContent=canvasMode==='mobile'?'Editando solo Móvil · datos del evento compartidos':'Editando PC · diseño móvil independiente';row.append(note);panel.querySelector('header').append(row);
}
export async function setupDeviceHost(){
 const mobile=new URLSearchParams(location.search).get('device')==='mobile';
 if(!await finishProjectSave())return;
 document.body.classList.add('device-host');
 const stage=document.createElement('div');stage.className='device-stage';const toolbar=document.createElement('div');toolbar.className='device-preview-toolbar';
 const title=document.createElement('strong');title.textContent=mobile?'Vista móvil':'Vista PC';toolbar.append(title);
 const iframe=document.createElement('iframe');iframe.title=mobile?'Lienzo editable de la versión móvil':'Lienzo editable de la versión PC';iframe.className='device-phone';
 const screen=document.createElement('div');screen.className='device-screen';screen.append(iframe);let currentWidth=mobile?390:1280;const layout=()=>{const available=Math.max(160,stage.clientWidth-36),scale=Math.min(1,available/(currentWidth+12)),height=Math.max(200,stage.clientHeight-75);screen.style.width=(currentWidth+12)*scale+'px';screen.style.height=height+'px';iframe.style.width=currentWidth+'px';iframe.style.height=(height/scale-12)+'px';iframe.style.transform='scale('+scale+')';};window.addEventListener('resize',layout);
 for(const width of (mobile?[320,390,430]:[1024,1280,1440])){const b=document.createElement('button');b.textContent=width+' px';b.type='button';b.setAttribute('aria-pressed',String(width===currentWidth));b.addEventListener('click',()=>{currentWidth=width;layout();toolbar.querySelectorAll('button').forEach(n=>n.setAttribute('aria-pressed',String(n===b)));});toolbar.append(b);}
 const status=document.createElement('p');status.className='device-preview-status';status.textContent='Cargando el editor…';stage.append(toolbar,status,screen);document.body.append(stage);
 const url=new URL(location.href);url.searchParams.delete('device');url.searchParams.set('canvas',mobile?'mobile':'desktop');url.hash='/'+getPage();iframe.src=url.href;layout();
 window.addEventListener('message',event=>{if(event.origin!==location.origin||event.source!==iframe.contentWindow||event.data?.type!=='mobile-editor-ready')return;const panel=iframe.contentDocument.querySelector('#editor-panel');if(!panel)return;document.querySelector('#editor-root').append(document.adoptNode(panel));status.hidden=true;});
}
