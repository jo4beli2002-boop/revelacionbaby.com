import {PDFDocument,StandardFonts,rgb} from '../vendor/pdf-lib.esm.js';
const base64=bytes=>{let s='';for(let i=0;i<bytes.length;i+=8192)s+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(s);};
export async function invitationPDFs(env,families){
 const response=await env.ASSETS.fetch(new Request('https://assets.local/assets/invitacion-base.pdf'));
 if(!response.ok)throw Error('No se pudo cargar la invitación PDF.');
 const template=await response.arrayBuffer(),files=[];let total=0;
 for(const [i,f] of families.entries()){
  const pdf=await PDFDocument.load(template),page=pdf.getPage(0),font=await pdf.embedFont(StandardFonts.HelveticaBold);
  const headingFont=await pdf.embedFont(StandardFonts.Helvetica),heading='F a m i l i a';page.drawText(heading,{font:headingFont,size:27,x:(page.getWidth()-headingFont.widthOfTextAtSize(heading,27))/2,y:page.getHeight()-537,color:rgb(.435,.592,.808)});
  const text=(f.name+(f.detail?' ('+f.detail+')':'')).normalize('NFC').replace(/[^\u0020-\u007e\u00a0-\u00ff]/g,'');
  let size=43,lines=[];
  for(;size>=12;size--){lines=[];let line='';for(const word of text.split(/\s+/)){const next=line?line+' '+word:word;if(line&&font.widthOfTextAtSize(next,size)>430){lines.push(line);line=word;}else line=next;}if(line)lines.push(line);if(lines.length*size*1.15<=56&&lines.every(l=>font.widthOfTextAtSize(l,size)<=430))break;}
  for(const [n,line]of lines.entries())page.drawText(line,{font,size,x:(page.getWidth()-font.widthOfTextAtSize(line,size))/2,y:page.getHeight()-590+(lines.length-1)*size*.575-n*size*1.15,color:rgb(.665,.333,.22)});
  pdf.setTitle('Invitación · '+text);pdf.setAuthor('Una dulce sorpresa');
  const bytes=await pdf.save();total+=bytes.length;if(total>5*1024*1024)throw Error('Las invitaciones superan el límite de 5 MB. Confirma menos familias por registro.');
  files.push({name:'Invitacion-'+(i+1)+'.pdf',mimeType:'application/pdf',base64:base64(bytes)});
 }
 return files;
}
