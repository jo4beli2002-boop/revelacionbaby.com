import {spawnSync} from 'node:child_process';
import {createRequire} from 'node:module';
import path from 'node:path';
const require=createRequire(import.meta.url),cli=path.join(path.dirname(require.resolve('wrangler/package.json')),'bin/wrangler.js');
for(const args of [['deploy'],['d1','migrations','apply','DB','--remote']]){const result=spawnSync(process.execPath,[cli,...args],{stdio:'inherit',env:{...process.env,CI:'true'}});if(result.status!==0)process.exit(result.status||1);}
