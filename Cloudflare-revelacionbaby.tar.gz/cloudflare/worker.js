const SOURCE='https://revelacionbaby.srjo4bxin.chatgpt.site';
export async function forward(request,fetchImpl=fetch){
 const incoming=new URL(request.url);
 if(!['GET','HEAD','POST'].includes(request.method))return new Response('Método no permitido',{status:405});
 if(request.method==='POST'&&request.headers.get('Origin')!==incoming.origin)return new Response('Origen no permitido',{status:403});
 const target=new URL(SOURCE);target.pathname=incoming.pathname;target.search=incoming.search;
 const headers=new Headers();for(const key of ['accept','accept-language','content-type','range','if-range','if-none-match','if-modified-since']){const value=request.headers.get(key);if(value)headers.set(key,value);}
 const session=request.headers.get('cookie')?.split(';').map(x=>x.trim()).find(x=>x.startsWith('dulce_session='));if(session)headers.set('cookie',session);
 if(request.method==='POST')headers.set('Origin',SOURCE);
 const body=!['GET','HEAD'].includes(request.method)?request.body:null;
 try{
  const upstream=await fetchImpl(new Request(target,{method:request.method,headers,redirect:'manual',...(body?{body,duplex:'half'}:{})}));
  const result=new Headers(upstream.headers);result.delete('set-cookie');
  const cookies=upstream.headers.getSetCookie?.()||[upstream.headers.get('set-cookie')].filter(Boolean);
  for(const cookie of cookies)if(cookie.startsWith('dulce_session='))result.append('set-cookie',cookie.replace(/;\s*Domain=[^;]+/ig,''));
  const location=result.get('location');if(location){const redirect=new URL(location,SOURCE);if(redirect.origin===SOURCE){redirect.host=incoming.host;redirect.protocol=incoming.protocol;result.set('location',redirect.href);}}
  if(incoming.pathname.startsWith('/api/'))result.set('Cache-Control','no-store');
  result.set('X-Content-Type-Options','nosniff');result.set('Referrer-Policy','no-referrer');
  return new Response(request.method==='HEAD'?null:upstream.body,{status:upstream.status,statusText:upstream.statusText,headers:result});
 }catch{return new Response('No se pudo conectar con la invitación. Inténtalo de nuevo.',{status:502,headers:{'Cache-Control':'no-store'}});}
}
export default {fetch:request=>forward(request)};
